/* 
 * File:   Recursos.h
 * Author: administrador
 *
 * Created on 28 de julio de 2013, 08:25 PM
 */

#ifndef RECURSOS_H
#define	RECURSOS_H

float GetVm(unsigned char *ethname);
char* obtenerRecursos();

#endif	/* RECURSOS_H */


