/* 
 * File:   Extras.h
 * Author: administrador
 *
 * Created on 19 de julio de 2013, 02:29 PM
 */

#ifndef _EXTRAS_H
#define	_EXTRAS_H

char* obtenerIp();
char **split ( char *string, const char sep);
char* getName();
float getVmCable(char* ethname);
#endif	/* EXTRAS_H */

